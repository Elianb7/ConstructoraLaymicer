﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelo.Entidades
{
    public class Configuracion
    {
        public int ConfiguracionId { get; set; }
        public int MaxTurno { get; set; }
        public int MaxHorasTrabajadas { get; set; }
        public int PeriodoVigente { get; set; }

    }
}